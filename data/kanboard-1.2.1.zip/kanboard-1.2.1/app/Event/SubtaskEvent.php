<?php

namespace Kanboard\Event;

class SubtaskEvent extends GenericEvent
{
}
