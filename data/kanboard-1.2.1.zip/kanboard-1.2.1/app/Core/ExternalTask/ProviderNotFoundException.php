<?php

namespace Kanboard\Core\ExternalTask;

/**
 * Class ProviderNotFoundException
 *
 * @package Kanboard\Core\ExternalTask
 * @author  Frederic Guillot
 */
class ProviderNotFoundException extends ExternalTaskException
{
}
