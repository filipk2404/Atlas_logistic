<?php

namespace Kanboard\Core\Plugin;

use Exception;

/**
 * Class PluginException
 *
 * @package Kanboard\Core\Plugin
 * @author  Frederic Guillot
 */
class PluginException extends Exception
{
}
